<?php

$installUses = <<<PHP
use Mod\\CMSLite\\Src\\Controller\\CMSLiteController;
PHP;

$installRoutes = <<<PHP
    // CMS Lite index routes
    \$router->post('/ajax-contact', [IndexController::class, 'ajaxContact'], 'ajax_contact');
    \$router->post('/ajax-newsletter', [IndexController::class, 'ajaxNewsletter'], 'ajax_newsletter');
    // CMS Lite page routes
    \$router->get('/page/{slug}', [CMSLiteController::class, 'index'], 'page');
PHP;

$installValues = '';
