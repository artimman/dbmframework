<?php

$installConstants = <<<PHP
        //-KEY_CONSTANTS_CMSLITE
        public const FILEPATH_CONFIG_NAVIGATION_HEADER = BASE_DIRECTORY . 'config' . DS . 'navigation_header.json';
        public const FILEPATH_CONFIG_NAVIGATION_FOOTER = BASE_DIRECTORY . 'config' . DS . 'navigation_footer.json';
    PHP;
