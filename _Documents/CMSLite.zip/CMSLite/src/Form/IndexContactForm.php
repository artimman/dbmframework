<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use Dbm\Validation\Validator;

/**
 * Form validation for the Index contact form.
 */
class IndexContactForm extends Validator
{
    /**
     * Validate the contact form data.
     *
     * @param array $data Form input data.
     * @return array Validation errors.
     */
    public function validate(array $data): array
    {
        $data = $this->normalize($data);

        return $this->rules([
            'dbm_name' => ['required', 'string', 'regex:/^[\pL \'-]*$/u', 'min:2', 'max:60'],
            'dbm_email' => ['required', 'email'],
            'dbm_subject' => ['required', 'max:120'],
            'dbm_message' => ['required', 'max:2000'],
        ], $data);
    }
}
