<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\IndexContactForm;
use App\Service\IndexService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Http\Response;
use Dbm\Classes\Log\Logger;
use Dbm\Classes\Services\InstallerService;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;
use Exception;

class IndexController extends BaseController
{
    private readonly InstallerService $installer;

    /**
     * Constructor
     *
     * @param IndexService $indexService
     * @param DatabaseInterface|null $database [optional]
     */
    public function __construct(
        IndexService $indexService,
        ?DatabaseInterface $database = null
    ) {
        parent::__construct($database);

        // INFO: Jeśli poniższe klasy pozostają na stałe w projekcie lepiej wstrzykiwać je
        // przez kontener zależności (DI w pliku services.php), co pozwala łatwiej testować klasę.
        $this->installer = new InstallerService();
    }

    /**
     * Index page
     * @routing GET '/' name: index
     *
     * @param IndexService $indexService
     * @return ResponseInterface
     */
    public function index(IndexService $indexService): ResponseInterface
    {
        // Create a New Project (templates/index/index.phtml)!
        return $this->render('index/index.phtml', [
            'meta' => $indexService->getMetaIndex(),
        ]);
    }

    /**
     * Start page
     * @routing GET '/start' name: start
     *
     * @param IndexService $indexService
     * @return ResponseInterface
     */
    public function start(IndexService $indexService): ResponseInterface
    {
        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaStart(),
        ]);
    }

    /**
     * Installer page
     * @routing GET '/installer' name: installer
     *
     * @param IndexService $indexService
     * @param Request $request
     * @return ResponseInterface
     */
    public function installer(IndexService $indexService, Request $request): ResponseInterface
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'install';
        $pathManifest = BASE_DIRECTORY . '_Documents' . DS . 'install' . DS . 'module.json';

        if (class_exists('\\App\\Controller\\InstallController')) {
            $action = $request->getQuery('action');

            if ($action === 'remove') {
                $msg = $this->installer->uninstallModule($dirModule, $pathManifest);

                if (!empty($msg)) {
                    $alert = $indexService->alertMessage($msg);
                    $this->setFlash($alert['type'], $alert['message']);
                }

                return $this->redirect('./start');
            } else {
                $this->setFlash('messageInfo', $this->translation->trans('install.alert.installer_active'));
            }
        } else {
            $pathZip = BASE_DIRECTORY . '_Documents' . DS . 'install.zip';

            $msg = $this->installer->installModule($dirModule, $pathManifest, $pathZip);

            if (!empty($msg) && ($msg['type'] === 'success')) {
                $msg['message'] = $this->translation->trans('install.alert.link.continue', [], ['./install']);
            }

            $alert = $indexService->alertMessage($msg);
            $this->setFlash($alert['type'], $alert['message']);
        }

        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaInstaller(),
        ]);
    }

    /**
     * Handle contact form submission via AJAX.
     * @routing POST '/ajax-contact' name: ajax_contact
     *
     * @param IndexService $indexService
     * @param Request $request
     * @return ResponseInterface
     */
    public function ajaxContact(IndexService $indexService, Request $request, Logger $logger): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return Response::text("Invalid request method.", 405);
            }

            $bodyParams = (array) $request->getParsedBody();

            if (!$this->validateCsrfToken($bodyParams)) {
                return Response::text("Invalid CSRF token.", 403);
            }

            $validator = new IndexContactForm();
            $errors = $validator->validate($bodyParams);

            if (!empty($errors)) {
                return Response::text("Invalid form data.", 422);
            }

            $isSent = $indexService->makeContactMessage($bodyParams);

            if ($isSent) {
                return Response::text("OK", 200); // JS expects "OK"
            } else {
                return Response::text("Failed to send message. Please try again.", 500);
            }
        } catch (Exception $exception) {
            $logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::text("An error occurred while processing your request.", 500);
        }
    }

    /**
     * Newsletter form
     * @routing POST '/ajax-newsletter' name: ajax_newsletter
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function ajaxNewsletter(Request $request, Logger $logger): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return Response::text("Invalid request method.", 405);
            }

            // INFO: Add newsletter subscription logic here.
            return Response::text("OK", 200); // JS expects "OK"
        } catch (Exception $exception) {
            $logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::text("An error occurred while processing your request.", 500);
        }
    }
}
