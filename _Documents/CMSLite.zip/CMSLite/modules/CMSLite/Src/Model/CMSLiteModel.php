<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CMSLite\Src\Model;

use Dbm\Classes\DataFlatfile;
use Dbm\Classes\Dto\FileOperationDto;

class CMSLiteModel
{
    private $datafile;

    public function __construct()
    {
        $this->datafile = new DataFlatfile();
    }

    public function getDatafile(): DataFlatfile
    {
        return $this->datafile;
    }

    public function Title(): string
    {
        $dataFile = $this->datafile->dataFlatFile('title');

        if ($dataFile->isSuccess()) {
            return $dataFile->getData();
        }

        return 'errorTitle';
    }

    public function Description(): string
    {
        $dataFile = $this->datafile->dataFlatFile('description');

        if ($dataFile->isSuccess()) {
            return $dataFile->getData();
        }

        return 'errorDescription';
    }

    public function Keywords(): string
    {
        $dataFile = $this->datafile->dataFlatFile('keywords');

        if ($dataFile->isSuccess()) {
            return $dataFile->getData();
        }

        return 'errorKeywords';
    }

    public function Content(): FileOperationDto
    {
        return $this->datafile->dataFlatFile('content', '7');
    }
}
