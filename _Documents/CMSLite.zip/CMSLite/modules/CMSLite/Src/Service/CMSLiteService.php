<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CMSLite\Src\Service;

use Mod\CMSLite\Src\Model\CMSLiteModel;

class CMSLiteService
{
    private $model;

    public function __construct(CMSLiteModel $model)
    {
        $this->model = $model;
    }

    public function getMetaPage(): array
    {
        return [
            'meta.title' => $this->model->Title(),
            'meta.description' => $this->model->Description(),
            'meta.keywords' => $this->model->Keywords(),
        ];
    }
}
