<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CMSLite\Src\Controller;

use Dbm\Classes\BaseController;
use Dbm\Interfaces\DatabaseInterface;
use Mod\CMSLite\Src\Model\CMSLiteModel;
use Mod\CMSLite\Src\Service\CMSLiteService;
use Psr\Http\Message\ResponseInterface;

class CMSLiteController extends BaseController
{
    private $model;
    private $service;

    public function __construct(?DatabaseInterface $database = null)
    {
        parent::__construct($database);

        $this->model = new CMSLiteModel();
        $this->service = new CMSLiteService($this->model);
    }

    public function index(): ResponseInterface
    {
        $result = $this->model->Content();

        if (!$result->isSuccess()) {
            $this->setFlash('messageWarning', $result->getError());
        } else {
            $content = $result->getData();
        }

        return $this->render('page/index.phtml', [
            'meta' => $this->service->getMetaPage(),
            'content' => $content ?? null,
        ]);
    }
}
