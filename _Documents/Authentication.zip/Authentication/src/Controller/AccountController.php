<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\AccountPasswordForm;
use App\Form\AccountProfileForm;
use App\Repository\AccountRepository;
use App\Service\AccountService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Exception\UnauthorizedRedirectException;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;

class AccountController extends BaseController
{
    private AccountRepository $repository;
    private AccountService $service;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        if (empty($this->getSession(getenv('APP_SESSION_KEY')))) {
            throw new UnauthorizedRedirectException('./');
        }

        $this->repository = new AccountRepository($database);
        $this->service = new AccountService($this->repository);
    }

    /**
     * Method to handle user account overview.
     * @routing GET '/account' name: account
     *
     * @return ResponseInterface
     */
    public function index(): ResponseInterface
    {
        // INFO: Access is checked in the constructor (and Router), here it is an additional security measure.
        if (!$this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./");
        }

        $userId = (int) $this->getSession(getenv('APP_SESSION_KEY'));

        if ($userId <= 0) {
            return $this->redirect("./login");
        }

        $userAccount = $this->repository->userAccount($userId);

        return $this->render('account/index.phtml', [
            'meta' => ['meta.title' => $this->translation->trans('account.title') . ' - ' . getenv('APP_NAME')],
            'user' => $userAccount,
        ]);
    }

    /**
     * User profile view and update.
     * @routing GET|POST '/account/profile' name: account_profile|account_profile_post
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function accountProfile(Request $request): ResponseInterface
    {
        $id = (int) $this->getSession(getenv('APP_SESSION_KEY'));
        $userAccount = $this->repository->userAccount($id);
        $formData = [];

        if ($request->isMethod('POST')) {
            $formData = $this->service->filterFormData((array) $request->getParsedBody());

            if (!$this->validateCsrfToken($formData)) {
                return $this->withDangerFlash('alert.invalid_csrf_token', './account/profile');
            }

            $validationErrors = [];
            $avatar = $this->service->processAvatarUpload($request);

            if (is_array($avatar) && ($avatar['status'] ?? '') === 'success') {
                $formData['file_avatar'] = $avatar['data'];
            } elseif (!empty($avatar['message'])) {
                $validationErrors['error_avatar'] = $avatar['message'];
            }

            $formProfile = new AccountProfileForm($this->translation);
            $validationErrors += $formProfile->validate($formData);

            if (empty($validationErrors)) {
                $updated = $this->service->makeUpdateUserProfile($id, $formData, $userAccount);

                if ($updated) {
                    $newAvatar = trim((string)($formData['file_avatar'] ?? ''));
                    if ($newAvatar !== '') {
                        $this->service->deleteOldAvatar($userAccount->avatar, $newAvatar);
                    }

                    return $this->withSuccessFlash('Profil został pomyślnie edytowany.', './account');
                }

                return $this->withDangerFlash('Wystąpił nieoczekiwany błąd podczas edycji profilu!', './account');
            }

            $formData = array_merge($formData, $validationErrors);
        }

        return $this->render('account/profile.phtml', [
            'meta' => ['meta.title' => 'Edycja profilu użytkownika'],
            'user' => $userAccount,
            'form' => $formData ?: null,
        ]);
    }

    /**
     * User password change.
     * @routing GET|POST '/account/password' name: account_password|account_password_post
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function accountPassword(Request $request): ResponseInterface
    {
        $id = (int) $this->getSession(getenv('APP_SESSION_KEY'));
        $userAccount = $this->repository->userAccount($id);
        $formData = [];

        if ($request->isMethod('POST')) {
            $formData = $this->service->filterFormData((array) $request->getParsedBody());

            if (!$this->validateCsrfToken($formData)) {
                return $this->withDangerFlash('alert.invalid_csrf_token', './account/password');
            }

            $formPassword = new AccountPasswordForm($this->repository, $this->translation);
            $validationErrors = $formPassword->validate($formData, $id);

            if (empty($validationErrors)) {
                $password = trim($formData['dbm_password'] ?? '');
                $updated = $this->service->makeUpdatePassword($id, $password);

                if ($updated) {
                    return $this->withSuccessFlash('Hasło zostało pomyślnie zmienione.', './account');
                }

                return $this->withDangerFlash('Wystąpił nieoczekiwany błąd podczas zmiany hasła!', './account');
            }

            $formData = array_merge($formData, $validationErrors);
        }

        return $this->render('account/password.phtml', [
            'meta' => ['meta.title' => 'Zmiana hasła'],
            'user' => $userAccount,
            'form' => $formData ?: null,
        ]);
    }

    /**
     * Success flash message and redirect.
     *
     * @param string $message
     * @param string $redirectTo
     * @return ResponseInterface
     */
    private function withSuccessFlash(string $message, string $redirectTo): ResponseInterface
    {
        $this->setFlash('messageSuccess', $this->translation->trans($message) ?: $message);
        return $this->redirect($redirectTo);
    }

    /**
     * Danger flash message and redirect.
     *
     * @param string $message
     * @param string $redirectTo
     * @return ResponseInterface
     */
    private function withDangerFlash(string $message, string $redirectTo): ResponseInterface
    {
        $this->setFlash('messageDanger', $this->translation->trans($message) ?: $message);
        return $this->redirect($redirectTo);
    }
}
