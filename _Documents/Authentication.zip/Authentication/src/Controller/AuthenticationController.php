<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\AuthenticationLoginForm;
use App\Form\AuthenticationRegisterForm;
use App\Form\AuthenticationResetPassForm;
use App\Form\AuthenticationResetPasswordForm;
use App\Repository\AuthenticationRepository;
use App\Service\AuthenticationService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Log\Logger;
use Dbm\Classes\RememberMe;
use Dbm\Classes\Services\SanitizeService;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;

class AuthenticationController extends BaseController
{
    private AuthenticationRepository $repository;
    private AuthenticationService $service;
    private RememberMe $remember;
    private Logger $logger;
    private SanitizeService $sanitize;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        $this->repository = new AuthenticationRepository($database, $this->translation);
        $this->service = new AuthenticationService($this->repository, $this->translation);
        $this->remember = new RememberMe($database, $this);
        $this->logger = new Logger();
        $this->sanitize = new SanitizeService();
    }

    /**
     * Logowanie użytkownika
     * @routing GET '/login' name: login
     *
     * @return ResponseInterface
     */
    public function login(): ResponseInterface
    {
        if ($this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./account");
        }

        return $this->render('authentication/login.phtml', [
            'meta' => $this->service->getMetaLogin(),
        ]);
    }

    /**
     * Obsługa logowania użytkownika
     * @routing POST '/login/signin' name: login_signin
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function loginSignin(Request $request): ResponseInterface
    {
        if (!$request->isMethod('POST')) {
            return $this->redirect('./login');
        }

        $bodyParams = (array) $request->getParsedBody();

        if (!$this->validateCsrfToken($bodyParams)) {
            return $this->redirectWithFlash('./login', 'messageDanger', 'alert.invalid_csrf_token');
        }

        $formLogin = new AuthenticationLoginForm($this->repository, $this->translation);
        $formData = $this->service->filterFormData($bodyParams);
        $validationErrors = $formLogin->validate($formData);

        if ($validationErrors['status'] === 'success') {
            if (!empty($formData['dbm_remember_me']) && is_string($formData['dbm_remember_me'])) {
                $this->remember->createRememberMe((int) $validationErrors['user_id']);
            }

            if (!session_regenerate_id(true)) {
                $this->logger->error("Failed to regenerate session ID in loginSignin()!");
                return $this->redirectWithFlash('./login', 'messageDanger', 'alert.invalid_csrf_token');
            }

            $this->setSession(getenv('APP_SESSION_KEY'), $validationErrors['user_id']);
            $this->setFlash("messageSuccess", $this->translation->trans('authn.login.alert.logged_in_system'));
            return $this->redirect("./account");
        }

        $this->setFlash("messageWarning", $validationErrors['message']);

        return $this->render('authentication/login.phtml', [
            'meta' => $this->service->getMetaLogin(),
            'fields' => $formData,
            'validate' => null,
        ]);
    }

    /**
     * Wylogowanie użytkownika
     * @routing GET '/login/logout' name: login_logout
     *
     * @return ResponseInterface
     */
    public function loginLogout(): ResponseInterface
    {
        if ($this->remember->checkRememberMe()) {
            $this->remember->removeRememberMe();
        }

        $this->destroySession();
        return $this->redirectWithFlash('./', 'messageSuccess', 'authn.login.alert.logged_out_system');
    }

    /**
     * Rejestracja użytkownika
     * @routing GET '/register' name: register
     *
     * @return ResponseInterface
     */
    public function register(): ResponseInterface
    {
        if ($this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./account");
        }

        return $this->render('authentication/register.phtml', [
            'meta' => $this->service->getMetaRegister(),
        ]);
    }

    /**
     * Obsługa rejestracji użytkownika
     * @routing POST '/register/signup' name: register_signup
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function registerSignup(Request $request): ResponseInterface
    {
        if (!$request->isMethod('POST')) {
            return $this->redirect('./register');
        }

        $bodyParams = (array) $request->getParsedBody();

        if (!$this->validateCsrfToken($bodyParams)) {
            return $this->redirectWithFlash('./login', 'messageDanger', 'alert.invalid_csrf_token');
        }

        $formRegister = new AuthenticationRegisterForm($this->repository, $this->translation);
        $formData = $this->service->filterFormData($bodyParams);
        $validationErrors = $formRegister->validate($formData);

        if (!$validationErrors) {
            $success = $this->service->makeInsertCreateAccount($formData);
            $redirectPath = $success ? "./login" : "./register";
            $messageType = $success ? "messageSuccess" : "messageDanger";
            $messageKey = $success
                ? 'authn.register.alert.account_created'
                : 'alert.unexpected_error_try_again';

            $this->setFlash($messageType, $this->translation->trans($messageKey));

            return $this->redirect($redirectPath);
        }

        return $this->render('authentication/register.phtml', [
            'meta' => $this->service->getMetaRegister(),
            'fields' => $formData,
            'validate' => $validationErrors,
        ]);
    }

    /**
     * Weryfikacja konta użytkownika
     * @routing GET '/register/verified?token={token}' name: register_verified
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function registerVerified(Request $request): ResponseInterface
    {
        $token = $this->sanitize->sanitizeToken($request->getQuery('token') ?? '');

        if (empty($token)) {
            return $this->redirectWithFlash('./login', 'messageDanger', 'authn.register.alert.no_token');
        }

        if (!$this->repository->isTokenValid($token)) {
            return $this->redirectWithFlash('./login', 'messageWarning', 'authn.register.alert.token_expired');
        }

        $updated = $this->repository->verifyUser($token);

        $this->setFlash(
            $updated ? "messageSuccess" : "messageDanger",
            $this->translation->trans($updated
                ? 'authn.register.alert.account_verified'
                : 'alert.unexpected_error')
        );

        return $this->redirect("./login");
    }

    /**
     * Resetowanie hasła
     * @routing GET '/reset' name: reset
     *
     * @return ResponseInterface
     */
    public function reset(): ResponseInterface
    {
        if ($this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./account");
        }

        return $this->render('authentication/reset.phtml', [
            'meta' => $this->service->getMetaReset(),
        ]);
    }

    /**
     * Resetowanie hasła
     * @routing POST '/reset/pass' name: reset_pass
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function resetPass(Request $request): ResponseInterface
    {
        if (!$request->isMethod('POST')) {
            return $this->redirect('./reset');
        }

        $bodyParams = (array) $request->getParsedBody();

        if (!$this->validateCsrfToken($bodyParams)) {
            return $this->redirectWithFlash('./login', 'messageDanger', 'alert.invalid_csrf_token');
        }

        $formResetPass = new AuthenticationResetPassForm($this->repository, $this->translation);
        $formData = $this->service->filterFormData($bodyParams);
        $validationErrors = $formResetPass->validate($formData);

        if (empty($validationErrors)) {
            $this->repository->deleteResetPassword();
            $resetPassword = $this->service->makeInsertResetPassword(trim($formData['dbm_email']) ?? '');

            if ($resetPassword) {
                return $this->redirectWithFlash('./login', 'messageSuccess', 'authn.reset.alert.send_reset_password');
            } else {
                return $this->redirectWithFlash('./reset', 'messageDanger', 'alert.unexpected_error_try_again');
            }
        } elseif (!empty($validationErrors['error_no_email'])) {
            return $this->redirectWithFlash('./login', 'messageSuccess', 'authn.reset.alert.send_reset_password');
        } else {
            return $this->render('authentication/reset.phtml', [
                'meta' => $this->service->getMetaReset(),
                'fields' => $formData,
                'validate' => $validationErrors,
            ]);
        }
    }

    /**
     * Resetowanie hasła
     * @routing GET|POST '/reset/password?token={token}' name: reset_password|reset_password_post
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function resetPassword(Request $request): ResponseInterface
    {
        $token = $this->sanitize->sanitizeToken($request->get('token') ?? '');

        // Part of the method for the GET action
        if ($token) {
            $dataReset = $this->repository->getResetPassword(['token' => $token]);

            if ($token && (!$dataReset || $this->service->isTokenExpired($dataReset))) {
                return $this->redirectWithFlash('./reset', 'messageWarning', 'authn.reset.alert.token_expires');
            }
        }

        // Part of the method for the POST action
        if ($request->isPost()) {
            $bodyParams = (array) $request->getParsedBody();

            if (!$this->validateCsrfToken($bodyParams)) {
                return $this->redirectWithFlash('./login', 'messageDanger', 'alert.invalid_csrf_token');
            }

            $formResetPassword = new AuthenticationResetPasswordForm($this->translation);
            $formData = $this->service->filterFormData($bodyParams);
            $validationErrors = $formResetPassword->validate($formData);

            if (isset($dataReset) && empty($validationErrors)) {
                $isUpdated = $this->service->makeUpdateUserPassword($dataReset->email, $formData['dbm_password']);

                if ($isUpdated) {
                    return $this->redirectWithFlash('./login', 'messageSuccess', 'authn.reset.alert.updated_success');
                } else {
                    return $this->redirectWithFlash('./reset', 'messageDanger', 'alert.unexpected_error_try_again');
                }
            } else {
                $this->setFlash('messageDanger', $this->translation->trans('authn.reset.alert.validation_error'));
            }
        }

        return $this->render('authentication/reset_password.phtml', [
            'meta' => $this->service->getMetaReset(),
            'fields' => $formData ?? null,
            'validate' => $validationErrors ?? null,
            'token' => $token,
        ]);
    }

    /**
     * Helper method to redirect with flash message.
     */
    private function redirectWithFlash(string $route, string $type, string $messageKey): ResponseInterface
    {
        $this->setFlash($type, $this->translation->trans($messageKey));
        return $this->redirect($route);
    }
}
