<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use App\Repository\AuthenticationRepository;
use App\Utility\SanitizeUtility;
use Dbm\Interfaces\TranslationInterface;
use Lib\Sender\PHPMailerSender;
use Dbm\Classes\Log\Logger;
use DateTime;
use Dbm\Classes\Services\SanitizeService;
use Exception;

class AuthenticationService
{
    private const TOKEN_EXPIRES_TIME = '12'; // Token expiration time in hours, type string
    private $repository;
    private $translation;
    private $mailer;
    private $logger;
    private $sanitize;

    public function __construct(AuthenticationRepository $repository, TranslationInterface $translation)
    {
        $this->repository = $repository;
        $this->translation = $translation;
        $this->mailer = new PHPMailerSender();
        $this->logger = new Logger();
        $this->sanitize = new SanitizeService();
    }

    public function getMetaRegister(): array
    {
        return [
            'meta.title' => $this->translation->trans('authn.register.title') . ' - ' .  getenv('APP_NAME'),
            'meta.description' => $this->translation->trans('authn.register.description'),
            'meta.keywords' => $this->translation->trans('authn.register.keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function getMetaLogin(): array
    {
        return [
            'meta.title' => $this->translation->trans('authn.login.title') . ' - ' . getenv('APP_NAME'),
            'meta.description' => $this->translation->trans('authn.login.description'),
            'meta.keywords' => $this->translation->trans('authn.login.keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function getMetaReset(): array
    {
        return [
            'meta.title' => $this->translation->trans('authn.reset.title') . ' - ' . getenv('APP_NAME'),
            'meta.description' => $this->translation->trans('authn.reset.description'),
            'meta.keywords' => $this->translation->trans('authn.reset.keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function filterFormData(array $formData): array
    {
        return array_map(function ($value) {
            return is_string($value)
                ? filter_var(trim($value), FILTER_SANITIZE_SPECIAL_CHARS)
                : $value;
        }, $formData);
    }

    public function isTokenExpired($dataReset): bool
    {
        return empty($dataReset->expires) || (new DateTime($dataReset->expires) < new DateTime());
    }

    public function makeInsertCreateAccount(array $formData): bool
    {
        try {
            $login = $this->sanitize->sanitizeInsert($formData['dbm_login']);
            $email = filter_var($formData['dbm_email'], FILTER_VALIDATE_EMAIL);
            $password = password_hash($formData['dbm_password'], PASSWORD_DEFAULT);
            $token = bin2hex(random_bytes(20));

            if (!$email) {
                return false;
            }

            $insertData = [
                'login' => $login,
                'email' => $email,
                'password' => $password,
                'token' => $token
            ];

            $this->repository->insertCreateAccount($insertData);

            if (!$this->sendRegistrationEmail($login, $email, $token)) {
                // TODO! Można dopisać rollback() -> insertCreateAccount()
                $this->logger->error('Something is wrong with email configuration. Details: makeInsertCreateAccount() -> sendRegistrationEmail().');
                return false;
            }

            return true;
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return false;
        }
    }

    public function makeInsertResetPassword(string $email): bool
    {
        try {
            $expiresTime = self::TOKEN_EXPIRES_TIME;
            $expiresAt = date('Y-m-d H:i:s', strtotime("+$expiresTime hour"));
            $tokenReset = bin2hex(random_bytes(32));

            $insertData = [
                'email' => $email,
                'token' => $tokenReset,
                'expires' => $expiresAt,
            ];

            $this->repository->insertResetPassword($insertData);

            if (!$this->sendResetPassword($email, $tokenReset, $expiresTime)) {
                // TODO! Można dopisać rollback() -> insertResetPassword()
                $this->logger->error('Something is wrong with email configuration. Details: makeInsertResetPassword() -> sendResetPassword()');
                return false;
            }

            return true;
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return false;
        }
    }

    public function makeUpdateUserPassword(string $email, string $password): bool
    {
        try {
            $updateData = [
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
            ];

            return $this->repository->updateUserPassword($updateData);
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return false;
        }
    }

    private function sendRegistrationEmail(string $login, string $email, string $token): bool
    {
        $arraySend = [
            'subject' => $this->translation->trans('authn.register.mailer.subject'),
            'sender_name' => getenv('MAIL_FROM_NAME'),
            'sender_email' => getenv('MAIL_FROM_EMAIL'),
            'recipient_name' => $login,
            'recipient_email' => $email,
            'message_content' => "register-created-account.html",
            'page_address' => getenv('APP_URL'),
            'token' => $token,
        ];

        return $this->mailer->sendMessage($arraySend);
    }

    private function sendResetPassword(string $email, string $token, string $expires): bool
    {
        $arraySend = [
            'subject' => $this->translation->trans('authn.reset.mailer.subject'),
            'sender_name' => getenv('MAIL_FROM_NAME'),
            'sender_email' => getenv('MAIL_FROM_EMAIL'),
            'recipient_email' => $email,
            'message_content' => "reset-password.html",
            'page_address' => getenv('APP_URL'),
            'token' => $token,
            'expires' => $expires,
        ];

        return $this->mailer->sendMessage($arraySend);
    }
}
