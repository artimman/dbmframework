<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use App\Repository\AccountRepository;
use Dbm\Classes\Http\Request;
use Lib\Upload\UploadImage;

class AccountService
{
    private const DIR_AVATAR = 'images/avatar/';
    private AccountRepository $repository;
    private $upload;

    public function __construct(AccountRepository $repository)
    {
        $this->repository = $repository;
        $this->upload = new UploadImage();
    }

    public function filterFormData(array $formData): array
    {
        return array_map(function ($value) {
            return is_string($value) ? filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS) : $value;
        }, $formData);
    }

    public function makeUpdateUserProfile(int $id, array $formData, object $userAccount): bool
    {
        $sqlUpdateDetails = [
            'id' => $id,
            'fullname' => $formData['dbm_fullname'],
            'phone' => $formData['dbm_phone'],
            'website' => $formData['dbm_website'],
            'profession' => $formData['dbm_profession'],
            'business' => $formData['dbm_business'],
            'address' => $formData['dbm_address'],
            'biography' => $formData['dbm_biography'],
        ];

        if (!empty($formData['file_avatar'])) {
            $sqlUpdateDetails['avatar'] = $formData['file_avatar'];
        }

        return $this->repository->updateUserDetails($sqlUpdateDetails);
    }

    public function makeUpdatePassword(int $id, string $newPassword): bool
    {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $sqlUpdate = [':password' => $hashedPassword, ':id' => $id];

        return $this->repository->updatePassword($sqlUpdate);
    }

    public function processAvatarUpload(Request $request): ?array
    {
        $uploadedFile = $request->getUploadedFile('dbm_avatar');

        if (!$uploadedFile || empty($uploadedFile['name'])) {
            return null;
        }

        $this->upload->setTargetDir(self::DIR_AVATAR);
        $this->upload->setAllowedTypes(['jpg', 'png', 'webp']);
        $this->upload->setMaxFileSize(1048576);
        $this->upload->setMaxWidth(520);
        $this->upload->setMaxHeight(520);

        return $this->upload->uploadImage($uploadedFile);
    }

    public function deleteOldAvatar(?string $oldAvatar, ?string $newAvatar): void
    {
        $oldAvatar = trim((string) $oldAvatar);
        $newAvatar = trim((string) $newAvatar);

        if (empty($oldAvatar) || $oldAvatar === $newAvatar) {
            return;
        }

        $filePath = rtrim(self::DIR_AVATAR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $oldAvatar;

        if (str_contains($oldAvatar, '..')) {
            return;
        }

        if (is_file($filePath)) {
            @unlink($filePath);
        }
    }
}
