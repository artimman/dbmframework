<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use Dbm\Interfaces\TranslationInterface;
use Dbm\Validation\Validator;

class AuthenticationResetPasswordForm extends Validator
{
    protected ?TranslationInterface $translation = null;

    public function __construct(?TranslationInterface $translation = null)
    {
        parent::__construct($translation);
    }

    /**
     * Validate new password form input.
     *
     * @param array $data
     * @return array
     */
    public function validate(array $data): array
    {
        $errors = [];

        if (empty($data['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_required');
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/", $data['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_pattern');
        }

        if (empty($data['dbm_password_repeat'])) {
            $errors['error_password_repeat'] = $this->translation->trans('authn.register.alert.password_confirmation_required');
        } elseif ($data['dbm_password'] !== $data['dbm_password_repeat']) {
            $errors['error_password_repeat'] = $this->translation->trans('authn.register.alert.password_confirmation_different');
        }

        return $errors;
    }
}
