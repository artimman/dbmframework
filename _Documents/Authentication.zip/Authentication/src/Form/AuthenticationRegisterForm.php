<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use App\Repository\AuthenticationRepository;
use Dbm\Interfaces\TranslationInterface;
use Dbm\Validation\Validator;

class AuthenticationRegisterForm extends Validator
{
    private AuthenticationRepository $repository;
    protected ?TranslationInterface $translation = null;

    public function __construct(AuthenticationRepository $repository, ?TranslationInterface $translation = null)
    {
        parent::__construct($translation);
        $this->repository = $repository;
    }

    /**
     * Validate registration form input.
     *
     * @param array $data
     * @return array
     */
    public function validate(array $data): array
    {
        // Walidacja ogólna
        $errors = $this->rules([
            'dbm_login' => ['required', 'string', 'min:2', 'max:30', 'regex:/^[a-z\d_]+$/i'],
            'dbm_email' => ['required', 'email', 'max:120'],
            // 'dbm_password' => ['required', 'string', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/', 'min:8', 'max:30'],
            // 'dbm_confirmation' => ['required', 'string', 'same:dbm_password'],
        ], $data);

        // Walidacja dodatkowa (custom rules)
        if (!empty($data['dbm_login']) && $this->repository->checkLogin($data['dbm_login'])) {
            $errors['error_login'] = $this->translation?->trans('authn.register.alert.login_exist');
        }

        if (!empty($data['dbm_email']) && $this->repository->checkEmail($data['dbm_email'])) {
            $errors['error_email'] = $this->translation?->trans('authn.register.alert.email_exist');
        }

        if (empty($data['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_required');
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/", $data['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_pattern');
        }

        if (empty($data['dbm_confirmation'])) {
            $errors['error_confirmation'] = $this->translation->trans('authn.register.alert.password_confirmation_required');
        } elseif ($data['dbm_password'] !== $data['dbm_confirmation']) {
            $errors['error_confirmation'] = $this->translation->trans('authn.register.alert.password_confirmation_different');
        }

        return $errors;
    }
}
