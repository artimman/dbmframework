<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use App\Repository\AccountRepository;
use Dbm\Interfaces\TranslationInterface;
use Dbm\Validation\Validator;

class AccountPasswordForm extends Validator
{
    private AccountRepository $repository;
    protected ?TranslationInterface $translation = null;

    public function __construct(AccountRepository $repository, ?TranslationInterface $translation = null)
    {
        parent::__construct($translation);
        $this->repository = $repository;
    }

    /**
     * Walidacja formularza zmiany hasła użytkownika.
     *
     * @param array $data
     * @param object $userData
     * @return array
     */
    public function validate(array $data, int $id): array
    {
        $userData = $this->repository->getUser($id);
        $errors = [];

        if (empty($data['dbm_password_old'])) {
            $errors['error_password_old'] = $this->translation->trans('authn.register.alert.password_required');
        } elseif (!password_verify($data['dbm_password_old'], $userData->password)) {
            $errors['error_password_old'] = $this->translation->trans('account.register.alert.password_incorrect');
        }

        if (empty($data['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_required');
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/", $data['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_pattern');
        }

        if (empty($data['dbm_password_repeat'])) {
            $errors['error_password_repeat'] = $this->translation->trans('authn.register.alert.password_confirmation_required');
        } elseif ($data['dbm_password'] !== $data['dbm_password_repeat']) {
            $errors['error_password_repeat'] = $this->translation->trans('authn.register.alert.password_confirmation_different');
        }

        return $errors;
    }
}
