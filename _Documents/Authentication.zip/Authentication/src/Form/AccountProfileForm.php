<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use Dbm\Interfaces\TranslationInterface;
use Dbm\Validation\Validator;

class AccountProfileForm extends Validator
{
    protected ?TranslationInterface $translation = null;

    public function __construct(?TranslationInterface $translation = null)
    {
        parent::__construct($translation);
    }

    /**
     * Walidacja formularza profilu użytkownika.
     *
     * @param array $data
     * @return array
     */
    public function validate(array $data): array
    {
        // Walidacja ogólna
        $errors = $this->rules([
            'dbm_fullname' => ['letters_spaces'],
            'dbm_phone' => ['phone'],
            'dbm_website' => ['url'],
            'dbm_profession' => ['string', 'letters_spaces', 'max:60'],
        ], $data);

        return $errors;
    }
}
