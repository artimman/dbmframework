<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use App\Repository\AuthenticationRepository;
use Dbm\Interfaces\TranslationInterface;
use Dbm\Validation\Validator;

class AuthenticationResetPassForm extends Validator
{
    private AuthenticationRepository $repository;
    protected ?TranslationInterface $translation = null;

    public function __construct(AuthenticationRepository $repository, ?TranslationInterface $translation = null)
    {
        parent::__construct($translation);
        $this->repository = $repository;
    }

    /**
     * Validate password reset request (email input).
     *
     * @param array $data
     * @return array
     */
    public function validate(array $data): array
    {
        // Walidacja ogólna
        $errors = $this->rules([
            'dbm_email' => ['required', 'email', 'max:120'],
        ], $data);

        // Walidacja dodatkowa (unikalna)
        if (!empty($data['dbm_email']) && !$this->repository->checkEmail($data['dbm_email'])) {
            $errors['error_no_email'] = $this->translation?->trans('authn.reset.alert.email_not_exist');
        }

        return $errors;
    }
}
