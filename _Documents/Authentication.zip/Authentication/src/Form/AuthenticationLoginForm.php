<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use App\Repository\AuthenticationRepository;
use Dbm\Interfaces\TranslationInterface;
use Dbm\Validation\Validator;

class AuthenticationLoginForm extends Validator
{
    private AuthenticationRepository $repository;
    protected ?TranslationInterface $translation = null;

    public function __construct(AuthenticationRepository $repository, ?TranslationInterface $translation = null)
    {
        parent::__construct($translation);
        $this->repository = $repository;
    }

    /**
     * Validate login form input and authenticate user.
     *
     * @param array $data
     * @return array
     */
    public function validate(array $data): array
    {
        // Walidacja ogólna
        $errors = $this->rules([
            'dbm_login' => ['required', 'string', 'min:2', 'max:60'],
            'dbm_password' => ['required', 'string', 'min:6', 'max:120'],
        ], $data);

        if (!empty($errors)) {
            return [
                'status' => 'error',
                'message' => $this->translation->trans('authn.login.alert.incorrect_login_details'),
                'errors'  => $errors,
            ];
        }

        // Walidacja dodatkowa (unikalna)
        $queryParams = [
            ':login' => $data['dbm_login'],
            ':email' => $data['dbm_login'],
        ];

        $correctUser = $this->repository->checkIsUserCorrect($queryParams, $data['dbm_password']);

        if (empty($correctUser) ||
            in_array($correctUser, [
                AuthenticationRepository::VALIDATION_LOGIN,
                AuthenticationRepository::VALIDATION_PASSWORD
            ], true)) {
            return [
                'status' => 'error',
                'message' => $this->translation->trans('authn.login.alert.incorrect_login_details'),
            ];
        }

        return [
            'status' => 'success',
            'user_id' => (int) trim($correctUser),
        ];
    }
}
