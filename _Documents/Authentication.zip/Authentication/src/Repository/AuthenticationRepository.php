<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Repository;

use Dbm\Interfaces\DatabaseInterface;

class AuthenticationRepository
{
    public const VALIDATION_LOGIN = 'loginNotFound';
    public const VALIDATION_PASSWORD = 'passwordNotMatched';

    private $database;

    public function __construct(DatabaseInterface $database)
    {
        $this->database = $database;
    }

    public function checkLogin(string $login): bool
    {
        $query = "SELECT 1 FROM dbm_user WHERE login = :login LIMIT 1";
        $this->database->queryExecute($query, [':login' => $login]);

        return (bool) $this->database->fetchColumn();
    }

    public function checkEmail(string $email): bool
    {
        $query = "SELECT 1 FROM dbm_user WHERE email = :email LIMIT 1";
        $this->database->queryExecute($query, [':email' => $email]);

        return (bool) $this->database->fetchColumn();
    }

    public function insertCreateAccount(array $data): bool
    {
        [$filteredQuery, $filteredParams] = $this->database->buildInsertQuery($data, 'dbm_user');

        if ($this->database->queryExecute($filteredQuery, $filteredParams)) {
            $userId = $this->database->getLastInsertId();
            $userData = ['user_id' => $userId];

            [$filteredQuery, $filteredParams] = $this->database->buildInsertQuery($userData, 'dbm_user_details');
            return $this->database->queryExecute($filteredQuery, $filteredParams);
        }

        return false;
    }

    public function isTokenValid(string $token): bool
    {
        $query = "SELECT COUNT(*) FROM dbm_user WHERE token = :token AND verified = false";
        $this->database->queryExecute($query, [':token' => $token]);

        return (bool) $this->database->fetchColumn();
    }

    public function verifyUser(string $token): bool
    {
        $query = "UPDATE dbm_user SET verified = true WHERE token = :token";
        return $this->database->queryExecute($query, [':token' => $token]);
    }

    public function checkIsUserCorrect(array $params, string $password): string
    {
        $query = "SELECT * FROM dbm_user WHERE (login=:login OR email=:email) AND verified=true LIMIT 1";

        $this->database->queryExecute($query, $params);

        if ($this->database->rowCount() == 0) {
            return self::VALIDATION_LOGIN;
        }

        $result = $this->database->fetchObject();

        if (!password_verify($password, $result->password)) {
            return self::VALIDATION_PASSWORD;
        }

        return (string) $result->id;
    }

    public function getResetPassword(array $data): ?object
    {
        $query = "SELECT * FROM dbm_reset_password WHERE token = :token LIMIT 1";

        $this->database->queryExecute($query, $data);

        if ($this->database->rowCount() == 0) {
            return null;
        }

        return $this->database->fetchObject();
    }

    public function insertResetPassword(array $data): bool
    {
        [$filteredQuery, $filteredParams] = $this->database->buildInsertQuery($data, 'dbm_reset_password');

        return $this->database->queryExecute($filteredQuery, $filteredParams);
    }

    public function deleteResetPassword(): bool
    {
        $expires = date('Y-m-d H:i:s', strtotime("+1 week"));
        $query = "DELETE FROM dbm_reset_password WHERE expires > :expires";

        return $this->database->queryExecute($query, [':expires' => $expires]);
    }

    public function updateUserPassword(array $data): bool
    {
        $passwordData = ['password' => $data['password']];
        [$filteredQuery, $filteredParams] = $this->database->buildUpdateQuery($passwordData, 'dbm_user', 'email=:email');

        $filteredParams['email'] = $data['email'];
        return $this->database->queryExecute($filteredQuery, $filteredParams);
    }
}
