<?php

$installClasses = [
    'AuthenticationController::class',
    'AccountController::class',
];

$installUses = <<<PHP
use App\\Controller\\AuthenticationController;
use App\\Controller\\AccountController;
PHP;

$installRoutes = <<<PHP
    // Authentication routes
    \$router->get('/login', [AuthenticationController::class, 'login'], 'login');
    \$router->post('/login/signin', [AuthenticationController::class, 'loginSignin'], 'login_signin');
    \$router->get('/login/logout', [AuthenticationController::class, 'loginLogout'], 'login_logout');
    \$router->get('/register', [AuthenticationController::class, 'register'], 'register');
    \$router->post('/register/signup', [AuthenticationController::class, 'registerSignup'], 'register_signup');
    \$router->get('/register/verified', [AuthenticationController::class, 'registerVerified'], 'register_verified');
    \$router->get('/reset', [AuthenticationController::class, 'reset'], 'reset');
    \$router->post('/reset/pass', [AuthenticationController::class, 'resetPass'], 'reset_pass');
    \$router->get('/reset/password', [AuthenticationController::class, 'resetPassword'], 'reset_password');
    \$router->post('/reset/password', [AuthenticationController::class, 'resetPassword'], 'reset_password_post');
    // Account routes
    \$router->guard('access_to_account', function () use (\$router) {
        \$router->get('/account', [AccountController::class, 'index'], 'account');
        \$router->get('/account/profile', [AccountController::class, 'accountProfile'], 'account_profile');
        \$router->post('/account/profile', [AccountController::class, 'accountProfile'], 'account_profile_post');
        \$router->get('/account/password', [AccountController::class, 'accountPassword'], 'account_password');
        \$router->post('/account/password', [AccountController::class, 'accountPassword'], 'account_password_post');
    });
PHP;

$installValues = '';
