<?php
/**
 * Demo: DbM DataTables PHP
 * @author Artur Malinowski
 */

declare(strict_types=1);

namespace App\Datatable;

use App\Enum\RoleEnum;
use Lib\DataTables\Src\Classes\JoinedRepository;
use Lib\DataTables\Src\Interfaces\ConfigDataTableInterface;
use Lib\DataTables\Src\Interfaces\DatabaseInterface;

class PanelUserConfigDataTable extends JoinedRepository implements ConfigDataTableInterface
{
    private const DEFAULT_MODE = 'PHP'; // You can change defalut 'PHP' to 'AJAX' or 'API' (in development)
    private const DEFAULT_URL = '/api/users'; // URL is required for options 'AJAX' and 'API'

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct(
            database: $database,
            table: $this->getTable(),
            primaryKey: $this->getPrimaryKey(),
            joins: $this->getJoins(),
            selectMap: $this->getSelectMap(),
            sortableMap: $this->getSortableMap(forRawSql: false),
            filterableMap: $this->getFilterableMap(forRawSql: false),
            searchable: $this->getSearchable()
        );
    }

    // --- Core config (SQL) ---

    private function getTable(): string
    {
        return 'dbm_user u';
    }

    private function getPrimaryKey(): string
    {
        return 'u.id';
    }

    private function getJoins(): array
    {
        return [
            'INNER JOIN dbm_user_details ud ON u.id = ud.user_id',
        ];
    }

    // --- Core config (Maps) ---

    public function getSelectMap(): array
    {
        return [
            'id' => 'u.id AS id',
            'login' => 'u.login AS login',
            'email' => 'u.email AS email',
            'roles' => 'u.roles AS roles',
            'verified' => 'u.verified AS verified',
            'created_at' => 'u.created_at AS created_at',
            'fullname' => 'ud.fullname AS fullname',
            'avatar' => 'ud.avatar AS avatar',
        ];
    }

    // --- Methods used by default and in the Raw SQL alternative option ---

    /**
     * Sort maps:
     * - forRawSql=false => in the repo we use table aliases (a./c./u.)
     * - forRawSql=true => in RAW we use aliases from SELECT (without prefixes)
     */
    private function getSortableMap(bool $forRawSql = false): array
    {
        return [
            'id' => 'u.id',
            'login' => 'u.login',
            'email' => 'u.email',
            'roles' => 'u.roles',
            'verified' => 'u.verified',
            'created_at' => 'u.created_at',
            'fulname' => 'ud.fullname',
            'avatar' => 'ud.avatar',
        ];
    }

    /**
     * Filter maps:
     * - forRawSql=false => repo: table aliases
     * - forRawSql=true => RAW: aliases from SELECT (without prefixes)
     */
    private function getFilterableMap(bool $forRawSql = false): array
    {
        return [
            'roles' => 'u.roles',
            'verified' => 'u.verified',
        ];
    }

    private function getSearchable(): array
    {
        return ['login', 'email', 'fullname', 'roles', 'created_at'];
    }

    public function getMaps(): array
    {
        return [
            'sortable' => $this->getSortableMap(forRawSql: true),
            'filterable' => $this->getFilterableMap(forRawSql: true),
            'searchable' => $this->getSearchable(),
        ];
    }

    // --- UI config ---

    public function getTableConfig(): array
    {
        return [
            [
                'field' => 'lp',
                'label' => '#',
                'virtual' => true,
                'formatter' => function (array $row, int $lp) {
                    return '<span class="fw-bold" title="ID: ' . $row['id'] . '">' . $lp . '</span>';
                }
            ],
            ['field' => 'id', 'label' => 'ID', 'name' => 'u.id', 'sortable' => true, 'hidden' => true],
            ['field' => 'login', 'label' => 'Login', 'sortable' => true, 'class' => 'fw-bold'],
            ['field' => 'email', 'label' => 'E-mail', 'sortable' => true],
            ['field' => 'fullname', 'label' => 'Imię i nazwisko', 'sortable' => true],
            ['field' => 'avatar', 'label' => 'Awatar', 'sortable' => false, 'class' => 'text-center', 'tag' => 'cell_image',
                'tag_options' => [
                    'row_name'  => 'avatar',
                    'src_dir' => '../images/avatar/',
                    'alt_field' => 'fullname',
                    'width' => 20,
                    'noimage' => 'no-avatar.png',
                ],
            ],
            ['field' => 'roles', 'label' => 'Rola', 'sortable' => true],
            [
                'field' => 'verified',
                'label' => 'Weryfikacja',
                'virtual' => true,
                'formatter' => function (array $row) {
                    return $this->customFieldVerified($row);
                }
            ],
            [
                'field' => 'created_at',
                'label' => 'Data rejestracji',
                'sortable' => true,
                'class' => 'text-nowrap',
                'formatter' => function (array $row) {
                    return !empty($row['created_at']) ? date('Y-m-d H:i', strtotime($row['created_at'])) : null;
                }
            ],
            ['field' => 'action', 'label' => 'Akcja', 'sortable' => false, 'class' => 'text-end', 'tag' => 'cell_action',
                'tag_options' => [
                    'actions' => [
                        [
                            'type'  => 'link',
                            'url' => '#create-edit?id={id}',
                            'label' => 'Edytuj',
                            'icon'  => 'bi bi-pencil-square',
                            'class' => 'text-primary',
                        ],
                        [
                            'type' => 'button',
                            'label' => 'Usuń',
                            'icon' => 'bi bi-trash',
                            'class' => 'text-danger deleteRecord',
                            'attrs' => [
                                'data-id' => '{id}',
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }

    public function getFilters(): array
    {
        $roleOptions = array_map(
            fn (RoleEnum $role) => ['value' => $role->value, 'label' => $role->value],
            array_filter(RoleEnum::cases(), fn (RoleEnum $role) => $role !== RoleEnum::GUEST)
        );

        return [
            'roles' => [
                'label' => 'Rola',
                'options' => $roleOptions,
            ],
            'verified' => [
                'label' => 'Weryfikacja',
                'options' => [
                    ['value' => 1, 'label' => 'Zweryfikowany'],
                    ['value' => 0, 'label' => 'Nie zweryfikowany'],
                ],
            ],
        ];
    }

    // TODO! Popraw, metoda nie powinna być jako wymagana.
    public function getButtons(): array
    {
        return [];
    }

    // --- Static methods ---

    /**
     * Configuration mode
     */
    public static function getMode(?string $mode = null): string
    {
        $allowed = ['PHP', 'AJAX', 'API'];
        $mode = $mode ? strtoupper($mode) : self::DEFAULT_MODE; // or global setting: ConstantConfig::DATATABLES_MODE

        return in_array($mode, $allowed, true) ? $mode : 'PHP';
    }

    /**
     * In the AJAX option, the URL for the dbm-datatables.js file is required
     */
    public static function getUrl(?string $url = null): ?string
    {
        return $url ?: self::DEFAULT_URL;
    }

    // TODO! Popraw, metoda nie powinna być jako wymagana.
    public static function getCustomRows(array $rows, array $columns): array
    {
        return [];
    }

    // --- Custom TableConfig Methods ---

    private function customFieldVerified(array $row): string
    {
        $verified = (bool) $row['verified'];

        if ($verified) {
            return '<span class="badge text-bg-success">Yes</span>';
        }

        return '<span class="badge text-bg-danger">No</span>';
    }
}
