<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Datatable\DatabaseAdapter;
use App\Datatable\PanelUserConfigDataTable;
use Dbm\Classes\BaseAdminController;
use Dbm\Classes\Http\Request;
use Dbm\Interfaces\DatabaseInterface;
use Lib\DataTables\Src\Classes\DataTableParams;
use Lib\DataTables\Src\Classes\DataTableService;
use Psr\Http\Message\ResponseInterface;

class PanelUserController extends BaseAdminController
{
    private DataTableService $dataTable;
    private PanelUserConfigDataTable $configDataTable;
    private DataTableParams $datatableParams;

    public function __construct(?DatabaseInterface $database = null)
    {
        parent::__construct($database);

        $adapterDB = new DatabaseAdapter($this->database);
        $this->dataTable = new DataTableService($adapterDB);
        $this->configDataTable = new PanelUserConfigDataTable($adapterDB);
        $this->datatableParams = new DataTableParams();
    }

    /**
     * Panel administracyjny
     * @routing GET '/[panel]/manage-users' name: panel_manage_users
     *
     * @return ResponseInterface
     */
    public function manageUsers(Request $request): ResponseInterface
    {
        $params = $request->getQueryParams();

        // Datatables
        $dtParams = $this->datatableParams->fromRequest($params);
        $dtResult = $this->dataTable
            ->withParams($dtParams)
            ->paginate($this->configDataTable);

        return $this->render('panel/manage_users.phtml', [
            'meta' => ['meta.title' => 'Zarządzanie użytkownikami'],
            'dt_records' => $dtResult->records,
            'dt_sider' => $dtResult->sider,
            'dt_config' => $this->configDataTable,
            'dt_mode' => $this->configDataTable->getMode(),
            'dt_url' => $this->configDataTable->getUrl(),
            'dt_query' => $this->configDataTable->getLastBuiltQuery(),
        ]);
    }
}
