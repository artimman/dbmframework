<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use Dbm\Classes\BaseAdminController;
use Dbm\Classes\Http\Request;
use Dbm\Interfaces\DatabaseInterface;
use Lib\Search\Src\Classes\SearchForm;
use Lib\Search\Src\Classes\SearchHelper;
use Lib\Search\Src\Classes\SearchService;
use Lib\Search\Src\Providers\UserDetailsSearchProvider;
use Lib\Search\Src\Providers\UserSearchProvider;
use Psr\Http\Message\ResponseInterface;

class PanelSearchController extends BaseAdminController
{
    private SearchForm $searchForm;

    public function __construct(?DatabaseInterface $database = null)
    {
        parent::__construct($database);

        $this->searchForm = new SearchForm();
    }

    /**
     * @return ResponseInterface
     *
     * @Route: "[panel]/search"
     */
    public function index(Request $request): ResponseInterface
    {
        if (!$this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./");
        }

        $query = $this->searchForm->sanitizeQuery($request->getQuery('q') ?? '');
        $filters = $this->searchForm->extractFilters($request->getQueryParams());
        $errors = $this->searchForm->getErrors();
        $providers = $filters['providers'] ?? [];

        $page = max(1, (int) $request->getQuery('page', 1));

        $service = new SearchService();
        $service->addProvider(new UserSearchProvider($this->database));
        $service->addProvider(new UserDetailsSearchProvider($this->database));

        $resultPage = $service->searchInAllProviders($query, $providers, $filters, $page, 2); // TEMP $limit = 2 - usun po testach

        return $this->render('panel/search.phtml', [
            'meta' => ['meta.title' => 'Panel Administracyjny - Wyszukiwarka'],
            'resultPage' => $resultPage,
            'query' => $query,
            'errors' => $errors,
        ]);
    }
}
