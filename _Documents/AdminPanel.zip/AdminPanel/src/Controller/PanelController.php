<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Utility\ActivityMonitorUtility;
use Dbm\Classes\BaseAdminController;
use Dbm\Interfaces\DatabaseInterface;
use Lib\Files\FileSystem;
use Psr\Http\Message\ResponseInterface;

class PanelController extends BaseAdminController
{
    // TODO! Zamien na PATH_DATA_CONTENT.
    private const DIR_CONTENT = BASE_DIRECTORY . 'data' . DS . 'content' . DS;

    private $filesystem;
    private $activity;

    public function __construct(?DatabaseInterface $database = null)
    {
        parent::__construct($database);

        $this->filesystem = new FileSystem();
        $this->activity = new ActivityMonitorUtility();
    }

    /**
     * Panel administracyjny
     * @routing GET '/[panel]' name: panel
     *
     * @return ResponseInterface
     */
    public function index(): ResponseInterface
    {
        // INFO: Access is checked in the constructor, here it is an additional security measure.
        if (!$this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./");
        }

        /* INFO: Dodane w BaseAdminController, opcjonalne w dowolnej metodzie:
        $userId = (int) $this->getSession(getenv('APP_SESSION_KEY'));
        if (!$this->accessControl->userCan($userId, 'access_to_admin_panel')) {
            throw new UnauthorizedRedirectException('../');
        } */

        $dataFiles = $this->filesystem->scanDirectory(self::DIR_CONTENT);
        $dataActivities = $this->activity->formatActivities();

        return $this->render('panel/admin.phtml', [
            'meta' => ['meta.title' => 'Panel Administracyjny'],
            'files' => $dataFiles,
            'articles' => null,
            'activities' => $dataActivities,
        ]);
    }
}
