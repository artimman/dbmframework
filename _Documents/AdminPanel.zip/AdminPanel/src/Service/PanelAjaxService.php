<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use App\Config\ConstantConfig;

class PanelAjaxService
{
    public function getTypeModule(string $type): string
    {
        switch ($type) {
            case 'article':
                $pathImage = ConstantConfig::PATH_IMAGES_BLOG;
                break;
            case 'section':
                $pathImage = ConstantConfig::PATH_IMAGES_BLOGCAT;
                break;
            default:
                $pathImage = ConstantConfig::PATH_IMAGES_PAGE;
        }

        return $pathImage;
    }
}
