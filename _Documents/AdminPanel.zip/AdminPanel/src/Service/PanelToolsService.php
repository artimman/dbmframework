<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

class PanelToolsService
{
    public function toolsPath(?string $type): string
    {
        switch ($type) {
            case 'mailer':
                $filePath = BASE_DIRECTORY . 'var' . DS . 'log' . DS . 'mailer' . DS;
                break;
            case 'logger':
                $filePath = BASE_DIRECTORY . 'var' . DS . 'log' . DS . 'logger' . DS;
                break;
            default:
                $filePath = BASE_DIRECTORY . 'var' . DS . 'log'. DS;
        }

        return $filePath;
    }

    public function getTitleAndLink(?string $type): array
    {
        $title = 'Dziennik błędów';
        $link = '?';

        if (!empty($type)) {
            $link = '?type=' . $type . '&';

            if ($type == 'mailer') {
                $title = $title . ' - Mailing';
            } elseif ($type == 'logger') {
                $title = $title . ' - Logger';
            }
        }

        return [$title, $link];
    }
}
