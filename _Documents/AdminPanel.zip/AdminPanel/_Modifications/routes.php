<?php

$installClasses = [
    'PanelController::class',
    'PanelPageController::class',
    'PanelToolsController::class',
    'PanelAjaxController::class',
    'PanelSearchController::class',
    'PanelUserController::class',
];

$installUses = <<<PHP
use App\\Controller\\PanelController;
use App\\Controller\\PanelPageController;
use App\\Controller\\PanelToolsController;
use App\\Controller\\PanelAjaxController;
use App\\Controller\\PanelSearchController;
use App\\Controller\\PanelUserController;
PHP;

$installRoutes = <<<PHP
    // Administration panel routes
    \$router->guard('access_to_admin_panel', function () use (\$router, \$panel) {
        \$router->get(\$panel, [PanelController::class, 'index'], 'panel');
        \$router->get(\$panel . '/manage-pages', [PanelPageController::class, 'managePages'], 'panel_manage_pages');
        \$router->get(\$panel . '/create-edit-page', [PanelPageController::class, 'createOrEditPage'], 'panel_create_edit_page');
        \$router->post(\$panel . '/create-edit-page', [PanelPageController::class, 'createOrEditPage'], 'panel_create_edit_page_post');
        \$router->post(\$panel . '/ajax-delete-page', [PanelPageController::class, 'ajaxDeletePage'], 'panel_ajax_delete_page');
        \$router->get(\$panel . '/manage-users', [PanelUserController::class, 'manageUsers'], 'panel_manage_users');
        \$router->get(\$panel . '/error-log', [PanelToolsController::class, 'errorLog'], 'panel_error_log');
        \$router->post(\$panel . '/ajax-upload-image', [PanelAjaxController::class, 'ajaxUploadImage'], 'panel_ajax_upload_image');
        \$router->post(\$panel . '/ajax-delete-image', [PanelAjaxController::class, 'ajaxDeleteImage'], 'panel_ajax_delete_image');
        \$router->get(\$panel . '/search', [PanelSearchController::class, 'index'], 'panel_search');
    });
PHP;

$installValues = <<<PHP
    \$panel = '/' . getenv('APP_PANEL');
PHP;
