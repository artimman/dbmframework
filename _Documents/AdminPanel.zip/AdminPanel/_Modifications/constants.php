<?php

$installConstants = <<<PHP
        //-KEY_CONSTANTS_ADMIN_PANEL
        public const PATH_IMAGES_PAGE = '../public/images/page/';
        public const PATH_IMAGES_BLOG = '../public/images/blog/';
        public const PATH_IMAGES_BLOGCAT = '../public/images/blog/category/';
    PHP;
