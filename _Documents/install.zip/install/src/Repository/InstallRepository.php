<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Repository;

use Dbm\Interfaces\DatabaseInterface;

class InstallRepository
{
    private ?DatabaseInterface $database = null;

    public function __construct(?DatabaseInterface $database = null)
    {
        $this->database = $database;
    }

    public function importDataFromFile(string $filePath): bool
    {
        return $this->database->importSqlFile($filePath);
    }

    public function isDatabaseInstalled(string $table): ?bool
    {
        if ($this->database === null) {
            return null;
        }

        $query = "SHOW TABLES LIKE '$table'";
        $this->database->queryExecute($query);

        return $this->database->rowCount() > 0;
    }
}
