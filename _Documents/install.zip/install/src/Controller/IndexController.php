<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Service\IndexService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Services\InstallerService;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;

class IndexController extends BaseController
{
    private readonly InstallerService $installer;

    /**
     * Constructor
     *
     * @param IndexService $indexService
     * @param DatabaseInterface|null $database [optional]
     */
    public function __construct(
        IndexService $indexService,
        ?DatabaseInterface $database = null
    ) {
        parent::__construct($database);

        $this->installer = new InstallerService();
    }

    /**
     * Index page
     * @routing GET '/' name: index
     *
     * @param IndexService $indexService
     * @return ResponseInterface
     */
    public function index(IndexService $indexService): ResponseInterface
    {
        // Create a New Project (templates/index/index.phtml)!
        $this->setFlash('messageInfo', $this->translation->trans('install.alert.application_ready'));

        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaIndex(),
        ]);
    }

    /**
     * Start page
     * @routing GET '/start' name: start
     *
     * @param IndexService $indexService
     * @return ResponseInterface
     */
    public function start(IndexService $indexService): ResponseInterface
    {
        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaStart(),
        ]);
    }

    /**
     * Installer page
     * @routing GET '/installer' name: installer
     *
     * @param IndexService $indexService
     * @param Request $request
     * @return ResponseInterface
     */
    public function installer(IndexService $indexService, Request $request): ResponseInterface
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'install';
        $pathManifest = BASE_DIRECTORY . '_Documents' . DS . 'install' . DS . 'module.json';

        if (class_exists('\\App\\Controller\\InstallController')) {
            $action = $request->getQuery('action');

            if ($action === 'remove') {
                $msg = $this->installer->uninstallModule($dirModule, $pathManifest);

                if (!empty($msg)) {
                    $alert = $indexService->alertMessage($msg);
                    $this->setFlash($alert['type'], $alert['message']);
                }

                return $this->redirect('./start');
            } else {
                $this->setFlash('messageInfo', $this->translation->trans('install.alert.installer_active'));
            }
        } else {
            $pathZip = BASE_DIRECTORY . '_Documents' . DS . 'install.zip';

            $msg = $this->installer->installModule($dirModule, $pathManifest, $pathZip);

            if (!empty($msg) && ($msg['type'] === 'success')) {
                $msg['message'] = $this->translation->trans('install.alert.link.continue', [], ['./install']);
            }

            $alert = $indexService->alertMessage($msg);
            $this->setFlash($alert['type'], $alert['message']);
        }

        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaInstaller(),
        ]);
    }
}
