<?php

$installConstants = <<<PHP
        //-KEY_CONSTANTS_INSTALL
        public const ARRAY_INSTALL_STEPS = [
            1 => ['action' => "start", 'text' => "install.menu.start", 'progress' => 0],
            2 => ['action' => "checkCMSLite", 'text' => "install.menu.check_cms_lite", 'progress' => 15],
            3 => ['action' => "createCMSLite", 'text' => "install.menu.create_cms_lite", 'progress' => 30],
            4 => ['action' => "createTable", 'text' => "install.menu.create_table", 'progress' => 45],
            5 => ['action' => "createAuthentication", 'text' => "install.menu.create_authentication", 'progress' => 60],
            6 => ['action' => "createAdminPanel", 'text' => "install.menu.create_admin_panel", 'progress' => 90],
            7 => ['action' => "finish", 'text' => "install.menu.finish", 'progress' => 100],
        ];
    PHP;
