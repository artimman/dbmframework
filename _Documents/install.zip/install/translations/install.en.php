<?php

// Install translation (English en-EN)
return [
    // Start template
    'start.navbar.home' => "Home (Build a New Project)",
    'start.navbar.install' => "Install (DbM CMS)",
    'start.navbar.extensions' => "Extensions",
    'start.navbar.download' => "Download",
    'start.header.title' => "Welcome to DbM Framework!",
    'start.header.subtitle' => "Your lightweight and flexible framework for building modern web applications.",
    'start.installation_progress' => "Installation progress",
    'start.features.header_one' => "High Performance",
    'start.features.description_one' => "Experience unparalleled speed and responsiveness in your applications. Our optimized architecture ensures minimal latency and efficient resource management, allowing your web applications to handle high traffic loads with ease and stability.",
    'start.features.header_two' => "Easy Configuration",
    'start.features.description_two' => "Get started quickly with our intuitive configuration options. Regardless of your experience, the framework provides user-friendly configuration and setup processes to match your project needs with minimal effort, reducing setup time and complexity.",
    'start.features.header_three' => "Comprehensive Documentation",
    'start.features.description_three' => "Our documentation includes best practices and step-by-step guides so you can easily create and deploy applications, ensuring smooth development and effective troubleshooting. With clear examples, you can optimize your work and overcome new challenges.",
    'start.action.header_one' => "Start Building New Project",
    'start.action.text_one_one' => "Go to the `src/Controller/IndexController.php` file and create the first page of your project in the index() method. If you won't be using the installer, go to the `application/routes.php` file and remove or comment out the `installer` route.",
    'start.action.text_one_two' => "Check out the documentation to get started with DbM Framework.",
    'start.action.text_one_three' => "Documentation is being developed.",
    'start.action.button_one' => "Go to documentation",
    'start.action.header_two' => "Install DbM CMS",
    'start.action.text_two_one' => "Use a ready-made authentication system, admin panel, and content management system powered by DbM Framework to launch your website without writing any code. Continue with the DbM CMS installation.",
    'start.action.text_two_two' => "Create websites, blogs, or portals - all customizable through an intuitive interface.",
    'start.action.button_two' => "Run the installer",
    'start.alert.cms_is_unavailable' => "Content management system installation is unavailable! If the installation process has completed, you can remove the top installation bar by going to the `header` template - remove the line `include start_navbar.phtml`!",
    'start.message.donation' => 'If DbM Framework has made your work easier or you appreciate the quality of our code, <a href="https://shopping.dbm.org.pl/payments/order.3.html" class="link-light" target="_blank">please support the project financially</a>. Every donation is an investment in its future.',
    'start.action.button_three' => "Install now",
    // Install service
    'install.install_meta_title' => "DbM CMS Installation :: Design by Malina",
    // Install template - Menu list
    'install.menu.start' => "Hello",
    'install.menu.check_cms_lite' => "System Check",
    'install.menu.create_cms_lite' => "CMS Lite Installation",
    'install.menu.create_table' => "Creating database tables",
    'install.menu.create_authentication' => "Create an authentication system",
    'install.menu.create_admin_panel' => "Create an admin panel",
    'install.menu.finish' => "Congratulations!",
    // Buttons
    'install.button.naxt_step' => "Next &rsaquo;&rsaquo;",
    'install.button.end' => "Go to DbM CMS &rsaquo;&rsaquo;",
    // Alerts
    'install.alert.application_ready' => "Your application is now ready and you can start working on a new project.",
    'install.alert.installer_active' => 'The installer is active. <a href="./install">Click here to continue &rsaquo;&rsaquo;</a>',
    'install.alert.check_system_requirements' => "Correct the system requirements to proceed to the next installation step.",
    'install.alert.database_import_success' => "Database import completed successfully!",
    'install.alert.database_already_exists' => "Database already exists, skipping import.",
    'install.alert.step.cmslite_created' => ' CMS Lite module created <a href="./" target="_blank">Preview &rsaquo;&rsaquo;</a>',
    'install.alert.step.authentication_created' => ' Authentication system created <a href="./" target="_blank">Preview &rsaquo;&rsaquo;</a>',
    'install.alert.step.admin_panel_created' => ' The administration panel has been createdd <a href="./" target="_blank">Preview &rsaquo;&rsaquo;</a>',
    'install.alert.step.finished' => ' The application is ready for use or further development. For security reasons, the installer has been removed. Login to admin account, login: Admin, password: Admin123, user account, password: Test123.',
    'install.alert.link.continue' => "Installation completed successfully. <a href=\"%s\">Click here to continue &rsaquo;&rsaquo;</a>",
    // Content text
    'install.content.step.start' => '
        <p><strong>DbM CMS</strong> is a fast and modern content management system, designed with simplicity of use and installation in mind. A ready-made solution based on a framework for those who want to quickly launch a website or application without having to code. It supports both simple pages and complex database-driven projects. If you don&amp;t have time to create your own modules, you can use ready-made tools for managing content, SEO and site structure. There are also ready-made modules (plugins) available, such as CMS Lite, CMS Core, CMS Pro and others, which you can quickly install and customize to your needs. An effective solution that speeds up project development without losing the flexibility of the framework.</p>
        <p>This installation process consists of 7 simple steps and will take about 5 minutes.</p>
        <p>Before you start using the application, please read the documentation at: <a href="https://dbm.org.pl/tworzenie/dbmframework" class="link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover" target="_blank">DbM Framework</a>.</p>
        <ol>
            <li>Go to the &quot;<strong>Installation and Configuration</strong>&quot; and follow the next steps.</li>
            <li>Configure the <strong>.htaccess</strong> files and fill in the configuration data in the <strong>.env</strong> file.</li>
            <li>Once the configuration is complete, proceed to the next step.</li>
        </ol>
        <p>Need help? Check the instructions or contact the author.</p>
    ',
    'install.content.step.create_cms_core' => '
        <p>Before importing the database, make sure that the information in the .env file is correct:</p>
        <ul>
            <li>Database server address</li>
            <li>Database name</li>
            <li>User name</li>
            <li>User password</li>
            <li>Character set and port (optional)</li>
        </ul>
        <p>This data should be available from your server administrator. If you do not have it, contact them before starting the import. If automatic creation of tables in the database does not work, you can import manually.</p>
    ',
];
