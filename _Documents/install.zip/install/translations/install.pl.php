<?php

// Install translation (Polish pl-PL)
return [
    // Start template
    'start.navbar.home' => "Strona główna (Utwórz Nowy Projekt)",
    'start.navbar.install' => "Zainstaluj (DbM CMS)",
    'start.navbar.extensions' => "Rozszerzenia",
    'start.navbar.download' => "Pobierz",
    'start.header.title' => "Witaj w DbM Framework!",
    'start.header.subtitle' => "Twoje lekkie i elastyczne środowisko do tworzenia nowoczesnych aplikacji internetowych.",
    'start.installation_progress' => "Postęp instalacji",
    'start.features.header_one' => "Wysoka wydajność",
    'start.features.description_one' => "Doświadcz niezrównanej szybkości i responsywności w swoich aplikacjach. Nasza zoptymalizowana architektura zapewnia minimalne opóźnienia i wydajne zarządzanie zasobami, dzięki czemu Twoje aplikacje internetowe mogą obsługiwać duże obciążenia ruchem z łatwością i stabilnością.",
    'start.features.header_two' => "Łatwa konfiguracja",
    'start.features.description_two' => "Szybko rozpocznij pracę dzięki naszym intuicyjnym opcjom konfiguracji. Niezależnie od Twojego doświadczenia, struktura zapewnia przyjazne dla użytkownika procesy konfiguracji i ustawień, aby dopasować się do potrzeb projektu przy minimalnym wysiłku, skracając czas konfiguracji i złożoność.",
    'start.features.header_three' => "Kompleksowa dokumentacja",
    'start.features.description_three' => "Nasza dokumentacja zawiera najlepsze praktyki i przewodniki krok po kroku, dzięki czemu możesz łatwo tworzyć i wdrażać aplikacje, zapewniając płynny rozwój i skuteczne rozwiązywanie problemów. Dzięki jasnym przykładom możesz zoptymalizować swoją pracę i pokonać nowe wyzwania.",
    'start.action.header_one' => "Rozpocznij tworzenie nowego projektu",
    'start.action.text_one_one' => "Przejdź do pliku `src/Controller/IndexController.php` i utwórz pierwszą stronę swojego projektu w metodzie index(). Jeśli nie będziesz używać instalatora, przejdź do pliku `application/routes.php` i usuń lub zakomentuj ścieżkę `installer`.",
    'start.action.text_one_two' => "Zapoznaj się z dokumentacją, aby rozpocząć korzystanie z DbM Framework.",
    'start.action.text_one_three' => "Dokumentacja jest w trakcie opracowywania.",
    'start.action.button_one' => "Przejdź do dokumentacji",
    'start.action.header_two' => "Zainstaluj DbM CMS",
    'start.action.text_two_one' => "Skorzystaj z gotowego systemu uwierzytelniania, panelu administracyjnego i systemu zarządzania treścią opartego na DbM Framework, aby uruchomić swoją stronę internetową bez pisania kodu. Kontynuuj instalację DbM CMS.",
    'start.action.text_two_two' => "Twórz strony internetowe, blogi i portale - wszystko z możliwością dostosowania za pomocą intuicyjnego interfejsu.",
    'start.action.button_two' => "Uruchom instalator",
    'start.alert.cms_is_unavailable' => "Instalacja systemu zarządzania treścią jest niedostępna! Jeśli proces instalacji się zakończył, możesz usunąć górny pasek instalacyjny, przechodząc do szablonu `header` - usuń wiersz `include start_navbar.phtml`!",
    'start.message.donation' => 'Jeśli DbM Framework ułatwił Ci pracę lub doceniasz jakość naszego kodu, <a href="https://shopping.dbm.org.pl/payments/order.3.html" class="link-light" target="_blank">wesprzyj projekt finansowo</a>. Każda darowizna to inwestycja w jego przyszłość.',
    'start.action.button_three' => "Zainstaluj teraz",
    // Install service
    'install.install_meta_title' => "Instalacja DbM CMS :: Design by Malina",
    // Install template - Menu list
    'install.menu.start' => "Witaj",
    'install.menu.check_cms_lite' => "Sprawdzenie systemu",
    'install.menu.create_cms_lite' => "Instalacja CMS Lite",
    'install.menu.create_table' => "Tworzenie tabel bazy danych",
    'install.menu.create_authentication' => "Utwórz system uwierzytelniania",
    'install.menu.create_admin_panel' => "Utwórz panel administracyjny",
    'install.menu.finish' => "Gratulacje!",
    // Buttons
    'install.button.naxt_step' => "Dalej &rsaquo;&rsaquo;",
    'install.button.end' => "Przejdź do DbM CMS &rsaquo;&rsaquo;",
    // Alerts
    'install.alert.application_ready' => "Twoja aplikacja jest już gotowa i możesz zacząć pracę nad nowym projektem.",
    'install.alert.installer_active' => 'Instalator jest aktywny. <a href="./install">Kliknij tutaj, aby kontynuować &rsaquo;&rsaquo;</a>',
    'install.alert.check_system_requirements' => "Popraw wymagania systemowe, aby przejść do kolejnego kroku instalacji.",
    'install.alert.database_import_success' => "Import bazy danych zakończony sukcesem!",
    'install.alert.database_already_exists' => "Baza danych już istnieje, pominięto import.",
    'install.alert.step.cmslite_created' => ' Moduł CMS Lite został utworzony <a href="./" target="_blank">Podgląd &rsaquo;&rsaquo;</a>',
    'install.alert.step.authentication_created' => ' System uwierzytelniania został utworzony <a href="./" target="_blank">Podgląd &rsaquo;&rsaquo;</a>',
    'install.alert.step.admin_panel_created' => ' Panel administracyjny został utworzony <a href="./" target="_blank">Podgląd &rsaquo;&rsaquo;</a>',
    'install.alert.step.finished' => ' Aplikacja jest gotowa do użycia lub dalszego rozwoju. Ze względów bezpieczeństwa instalator został usunięty. Logowanie na konto admina, login: Admin, hasło: Admin123, konto użytkownika, hasło: Test123.',
    'install.alert.link.continue' => "Instalacja zakończona pomyślnie. <a href=\"%s\">Kliknij tutaj, aby kontynuować &rsaquo;&rsaquo;</a>",
    // Content text
    'install.content.step.start' => '
        <p><strong>DbM CMS</strong> to szybki i nowoczesny system zarządzania treścią, stworzony z myślą o prostocie użytkowania i instalacji. Gotowe rozwiązanie oparte na frameworku dla tych, którzy chcą szybko uruchomić witrynę lub aplikację bez konieczności kodowania. Obsługuje zarówno proste strony, jak i złożone projekty oparte na bazie danych. Jeśli nie masz czasu na tworzenie własnych modułów, możesz użyć gotowych narzędzi do zarządzania treścią, SEO i strukturą witryny. Dostępne są także gotowe moduły (wtyczki), takie jak CMS Lite, CMS Core, CMS Pro oraz inne, które możesz szybko zainstalować i dostosować do swoich potrzeb. Efektywne rozwiązanie, które przyspiesza rozwój projektu bez utraty na elastyczności frameworka.</p>
        <p>Ten proces instalacji składa się z 7 prostych kroków i zajmie około 5 minut.</p>
        <p>Zanim zaczniesz korzystać z aplikacji zapoznaj się z dokumentacją pod adresem: <a href="https://dbm.org.pl/tworzenie/dbmframework" class="link-offset-2 link-offset-3-hover link-underline link-underline-opacity-0 link-underline-opacity-75-hover" target="_blank">DbM Framework</a>.</p>
        <ol>
            <li>Przejdź do sekcji &quot;<strong>Instalacja i konfiguracja</strong>&quot; i wykonaj kolejne kroki.</li>
            <li>Skonfiguruj pliki <strong>.htaccess</strong> oraz uzupełnij dane konfiguracyjne w pliku <strong>.env</strong>.</li>
            <li>Po zakończeniu konfiguracji przejdź do kolejnego kroku.</li>
        </ol>
        <p>Potrzebujesz pomocy? Sprawdź instrukcje lub skontaktuj się z autorem.</p>
    ',
    'install.content.step.create_cms_core' => '
        <p>Przed importem bazy danych upewnij się, że informacje w pliku .env są poprawne:</p>
        <ul>
            <li>Adres serwera bazy danych</li>
            <li>Nazwa bazy danych</li>
            <li>Nazwa użytkownika</li>
            <li>Hasło użytkownika</li>
            <li>Zestaw znaków oraz port (opcjonalne)</li>
        </ul>
        <p>Dane te powinny być dostępne u administratora serwera. Jeśli ich nie posiadasz, skontaktuj się z nim przed rozpoczęciem importu. Jeśli automatyczne tworzenie tabel w bazie danych nie zadziała, możesz przeprowadzić import manualnie.</p>
    ',
];
