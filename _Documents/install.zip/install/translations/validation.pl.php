<?php

// Validation translation (Polish pl-PL)
// You can use or add a translation key for :field, e.g. 'validation.required' => 'The :field is required.', // etc.
return [
    'validation.required' => "Pole jest wymagane.",
    'validation.min' => "Pole musi mieć co najmniej :value znaków.",
    'validation.max' => "Pole nie może przekraczać :value znaków.",
    'validation.string' => "Pole musi być ciągiem tekstowym.",
    'validation.email' => "Nieprawidłowy adres e-mail.",
    'validation.url' => "Pole musi być prawidłowym adresem URL.",
    'validation.phone' => "Pole musi zawierać prawidłowy numer telefonu.",
    'validation.letters_spaces' => "Pole może zawierać tylko litery, spacje i myślniki.",
    'validation.password' => "Pole musi spełniać wymagania dotyczące siły hasła.",
    'validation.confirmed' => "Pole potwierdzenia nie pasuje.",
    'validation.regex' => "Pole zawiera niedozwolone znaki.",
];
