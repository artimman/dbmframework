<?php

// Validation translation (English en-EN)
// You can use or add a translation key for :field, e.g. 'validation.required' => 'The :field is required.', // etc.
return [
    'validation.required' => "The field is required.",
    'validation.min' => "The field must be at least :value characters long.",
    'validation.max' => "The field cannot exceed :value characters long.",
    'validation.string' => "The field must be a string.",
    'validation.email' => "Invalid email address.",
    'validation.url' => "Field must be a valid URL.",
    'validation.phone' => "Field must be a valid phone number.",
    'validation.letters_spaces' => "Field can only contain letters, spaces, and dashes.",
    'validation.password' => "Field must meet the password strength requirements.",
    'validation.confirmed' => "Field confirmation does not match.",
    'validation.regex' => "The field contains invalid characters.",
];
